create
  definer = igor@`%` procedure Contract_Update_Start(IN t int)
BEGIN
	UPDATE  ukn.contracts SET date_started = CAST(UNIX_TIMESTAMP() as UNSIGNED ) WHERE id = t;
END;

