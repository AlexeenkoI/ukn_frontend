create
  definer = igor@`%` procedure sel()
BEGIN
	select * from ukn.contracts;
END;

