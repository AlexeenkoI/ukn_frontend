create
  definer = igor@`%` procedure `select`()
BEGIN
	select * from ukn.contracts;
END;

